const express = require("express");
const cors = require("cors");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const app = express();
app.disable("x-powered-by");
app.use(cors({ origin: true }));
app.use(express.json({ limit: "100kb" }));
const PORT = Number(process.env.PORT || 3000);
const ROOT = path.join(__dirname, "..");
const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "orders.json");
const ADMIN_KEY = process.env.REDCORE_ADMIN_KEY || "local-admin-change-me";
const PRODUCTS = {tee:{id:"tee",name:"REDCORE T-SHIRT",price:49000},hoodie:{id:"hoodie",name:"REDCORE HOODIE",price:89000},pants:{id:"pants",name:"REDCORE PANTS",price:69000},cap:{id:"cap",name:"REDCORE CAP",price:39000}};
const STATUSES=["PAYMENT_PENDING","PAID","PREPARING","SHIPPED","DELIVERED","CANCELLED"];
app.use(express.static(ROOT,{extensions:["html"]}));
if(!fs.existsSync(DATA_DIR))fs.mkdirSync(DATA_DIR,{recursive:true});
if(!fs.existsSync(DATA_FILE))fs.writeFileSync(DATA_FILE,"[]","utf8");
function readOrders(){try{const x=JSON.parse(fs.readFileSync(DATA_FILE,"utf8"));return Array.isArray(x)?x:[]}catch{return[]}}
function writeOrders(x){fs.writeFileSync(DATA_FILE,JSON.stringify(x,null,2),"utf8")}
function clean(v,max=500){return String(v??"").trim().slice(0,max)}
function requireAdmin(req,res,next){if(req.get("x-redcore-admin-key")!==ADMIN_KEY)return res.status(401).json({error:"admin authentication required"});next()}
function calc(items){let subtotal=0;const normalized=[];for(const raw of items){const p=PRODUCTS[raw.productId];if(!p)throw new Error(`invalid product: ${raw.productId}`);const qty=Math.max(1,Math.min(99,Number(raw.quantity)||0));const size=clean(raw.size,10)||"M";if(!["S","M","L","XL"].includes(size))throw new Error("invalid size");subtotal+=p.price*qty;normalized.push({productId:p.id,name:p.name,size,quantity:qty,price:p.price})}const shipping=subtotal>=50000?0:3000;return{items:normalized,subtotal,shipping,total:subtotal+shipping}}
app.get("/api/health",(_req,res)=>res.json({ok:true,service:"REDCORE API",version:"final-local",storage:"persistent-json"}));
app.get("/api/products",(_req,res)=>res.json(Object.values(PRODUCTS)));
app.post("/api/orders",(req,res)=>{try{const customer=req.body?.customer||{};if(!Array.isArray(req.body?.items)||!req.body.items.length)return res.status(400).json({error:"items are required"});const name=clean(customer.name,80),phone=clean(customer.phone,30),address=clean(customer.address,300),memo=clean(customer.memo,300);if(!name||!phone||!address)return res.status(400).json({error:"customer information is incomplete"});const phoneDigits=phone.replace(/[^0-9]/g,"");if(!/^01[0-9]\d{7,8}$/.test(phoneDigits))return res.status(400).json({error:"invalid phone number"});const pricing=calc(req.body.items);const id=`RC-${new Date().toISOString().slice(0,10).replaceAll("-","")}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;const order={id,items:pricing.items,subtotal:pricing.subtotal,shipping:pricing.shipping,total:pricing.total,customer:{name,phone,address,memo},status:"PAYMENT_PENDING",createdAt:new Date().toISOString()};const orders=readOrders();orders.push(order);writeOrders(orders);res.status(201).json({order})}catch(err){res.status(400).json({error:err.message||"invalid order"})}});
app.get("/api/orders/:id",(req,res)=>{const o=readOrders().find(x=>x.id===req.params.id);if(!o)return res.status(404).json({error:"order not found"});res.json({order:{id:o.id,status:o.status,items:o.items,total:o.total,createdAt:o.createdAt}})});
app.get("/api/admin/orders",requireAdmin,(_req,res)=>res.json({orders:readOrders()}));
app.patch("/api/admin/orders/:id/status",requireAdmin,(req,res)=>{const orders=readOrders(),o=orders.find(x=>x.id===req.params.id);if(!o)return res.status(404).json({error:"order not found"});if(!STATUSES.includes(req.body?.status))return res.status(400).json({error:"invalid status"});o.status=req.body.status;o.updatedAt=new Date().toISOString();writeOrders(orders);res.json({order:o})});
app.listen(PORT,()=>console.log(`REDCORE is running at http://localhost:${PORT}`));
