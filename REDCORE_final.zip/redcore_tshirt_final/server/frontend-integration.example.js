// REDCORE frontend example
// POST /api/orders after collecting cart + customer information.

async function createOrder(items, customer) {
  const response = await fetch("/api/orders", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ items, customer })
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.error || "주문 생성에 실패했습니다.");
  }

  return response.json();
}
