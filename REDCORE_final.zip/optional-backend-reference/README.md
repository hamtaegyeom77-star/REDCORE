# REDCORE — optional backend reference

이 폴더는 **선택 사항**입니다. GitHub Pages에 배포되는 정적 사이트는 이 폴더
없이도 완전히 동작합니다 (주문은 브라우저 로컬 저장소를 사용합니다).

실제 결제(PG)나 여러 사용자의 주문을 한 곳에서 관리하는 진짜 서버가
필요해지면, 이 스타터 Express API를 참고해 연결하세요.

## 실행 (선택)
```
npm install
npm start
```
`http://localhost:3000/api/health` 로 정상 동작을 확인할 수 있습니다.

## 프런트엔드 연결 예시
`frontend-integration.example.js` 참고. `script.js`의 주문 제출 로직에서
로컬 저장 대신 이 API의 `POST /api/orders`를 호출하도록 바꾸면 됩니다.

## 주의
- JSON 파일(`data/orders.json`) 저장은 개발/학습용입니다. 실제 서비스에는
  데이터베이스, 관리자 인증 강화, HTTPS, 결제 승인 검증 등이 필요합니다.
- 실제 카드/간편결제는 결제대행사(PG) 계약과 별도 연동이 필요합니다.
